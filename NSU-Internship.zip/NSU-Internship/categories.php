<!DOCTYPE html>
<html lang="en">
<head>
    <title>NSU Internship Management System</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <?php 
          include('header/header.php');
    ?>
    <section class="nearJob">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-5 nearcol">
                    <h1>Your dream Internship</h1>
                    <h2 class="text-red">Is Near to You</h2>
                </div>
                <div class="col-sm-7 d-none d-md-block">
                    <div class="row">
                       <div class="d-flex w-100">
                         <img class="w-100" src="images/categories/banner.jpg" alt="Banner" />
                       </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="explore">
        <div class="container-fluid">
            <h3 class="text-center">Explore <span class="text-red"> By Categories</span></h3>
            <div class="row pb-5">
                <div class="col-sm-3 mb-4">
                    <a href="internship-job-list.html">
                        <div class="exoInner">
                            <i class="fa fa-bar-chart" aria-hidden="true"></i>
                            <h4>Web & Software</h4>
                            <p>122 Jobs</p>
                        </div>
                    </a>
                </div>
                <div class="col-sm-3 mb-4">
                    <a href="internship-job-list.html">
                        <div class="exoInner">
                            <i class="fa fa-file-text-o" aria-hidden="true"></i>
                            <h4>Data Science & Analist</h4>
                            <p>62 Jobs</p>
                        </div>
                    </a>
                </div>
                <div class="col-sm-3 mb-4">
                    <a href="internship-job-list.html">
                        <div class="exoInner">
                            <i class="fa fa-briefcase" aria-hidden="true"></i>
                            <h4>Business Development</h4>
                            <p>122 Jobs</p>
                        </div>
                    </a>
                </div>
                <div class="col-sm-3 mb-4">
                    <a href="internship-job-list.html">
                        <div class="exoInner">
                            <i class="fa fa-globe" aria-hidden="true"></i>
                            <h4>Digital Marketing</h4>
                            <p>25 Jobs</p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="row pb-4">
                <div class="col-sm-3 mb-4">
                    <a href="internship-job-list.html">
                        <div class="exoInner">
                            <i class="fa fa-cutlery" aria-hidden="true"></i>
                            <h4>Restaurant</h4>
                            <p>63 Jobs</p>
                        </div>
                    </a>
                    </div>
                <div class="col-sm-3 mb-4">
                    <a href="internship-job-list.html">
                        <div class="exoInner">
                            <i class="fa fa-linode" aria-hidden="true"></i>
                            <h4>Graphic Designing</h4>
                            <p>62 Jobs</p>
                        </div>
                    </a>
                </div>
                <div class="col-sm-3 mb-4">
                    <a href="internship-job-list.html">
                        <div class="exoInner">
                            <i class="fa fa-database" aria-hidden="true"></i>
                            <h4>Data Entry</h4>
                            <p>122 Jobs</p>
                        </div>
                    </a>
                </div>
                <div class="col-sm-3 mb-4">
                    <a href="internship-job-list.html">
                        <div class="exoInner">
                            <i class="fa fa-cogs" aria-hidden="true"></i>
                            <h4>Mechanic Engineering</h4>
                            <p>45 Jobs</p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 text-center">
                    <a href="#" class="btn btn-danger">View All Categroies</a>
                </div>
            </div>
        </div>
    </section>

    <section class="proFile">
      <div class="container my-4">	
        <h3 class="text-center pb-5">Best Internship For <span class="text-red">Your Profile</span></h3>
        <div id="slideProfile" class="carousel slide carousel-multi-item" data-ride="carousel">
           <div class="controls-top">
              <a class="btn-floating prev" href="#slideProfile" data-slide="prev"><i class="fa fa-long-arrow-left" aria-hidden="true"></i></a>
              <a class="btn-floating next" href="#slideProfile" data-slide="next"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a>
           </div>
           <div class="carousel-inner" role="listbox">
              <div class="carousel-item active">
                <div class="row">
                    <div class="col-md-4">
                        <a href="job-details.html">
                           <div class="card mb-2">
                                <div class="jobImage">
                                    <div class="image-card">
                                        <img class="card-img-top" src="images/categories/web.jpg" alt="Profile">
                                    </div>
                                </div>
                                <div class="card-body rgba-blue">
                                   <h4 class="text-white">Web Desiger</h4>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 clearfix d-none d-md-block">
                        <a href="job-details.html">
                            <div class="card mb-2">
                                <div class="jobImage">
                                    <div class="image-card">
                                        <img class="card-img-top" src="images/categories/ui-ux.png" alt="Profile">
                                    </div>
                                </div>
                                <div class="card-body rgba-blue">
                                    <h4 class="text-white">UI/UX Designer</h4>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-md-4 clearfix d-none d-md-block">
                        <a href="job-details.html">
                            <div class="card mb-2">
                                <div class="jobImage">
                                    <div class="image-card">
                                        <img class="card-img-top" src="images/categories/gd.jpg" alt="Profile">
                                    </div>
                                </div>
                                <div class="card-body rgba-blue">
                                    <h4 class="text-white">Graphic Designer</h4>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
              </div>
              <div class="carousel-item">
                    <div class="row">
                        <div class="col-md-4">
                            <a href="job-details.html">
                                <div class="card mb-2">
                                    <div class="jobImage">
                                        <div class="image-card">
                                            <img class="card-img-top" src="images/categories/web.jpg" alt="Profile">
                                        </div>
                                    </div>
                                    <div class="card-body rgba-blue">
                                        <h4 class="text-white">Web Desiger</h4>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 clearfix d-none d-md-block">
                            <a href="job-details.html">
                                <div class="card mb-2">
                                    <div class="jobImage">
                                        <div class="image-card">
                                            <img class="card-img-top" src="images/categories/ui-ux.png" alt="Profile">
                                        </div>
                                    </div>
                                    <div class="card-body rgba-blue">
                                        <h4 class="text-white">UI/UX Designer</h4>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-4 clearfix d-none d-md-block">
                            <a href="job-details.html">
                                <div class="card mb-2">
                                    <div class="jobImage">
                                        <div class="image-card">
                                            <img class="card-img-top" src="images/categories/gd.jpg" alt="Profile">
                                        </div>
                                    </div>
                                    <div class="card-body rgba-blue">
                                        <h4 class="text-white">Graphic Designer</h4>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
              </div>
           </div>
        </div>
      </div>
    </section>
    <?php 
          include("footer/footer.php");
    ?>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
