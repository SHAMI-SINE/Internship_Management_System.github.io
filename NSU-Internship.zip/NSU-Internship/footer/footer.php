<footer id="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-4 about-nsu-intern">
                <div class="col-sm-6">
                    <a class="logo-two" href="index.html">
                       <img src="images/logo/Logo.png" class="w-100 main-logo" alt="Logo" title="Logo" />
                    </a>
                </div>
                <div class="col-sm-6">
                    <div class="footer-content">
                        <p></p>
                    </div>
                    </div>
                </div>
                <div class="col-sm-4 contact-us-info">
                    <h5>Contact Us</h5>
                    <div class="footer-content">
                        <div class="media">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                            <div class="media-body">
                                <p>Block- A, Level-1, Bashundhara RA, Dhaka</p>
                            </div>
                        </div>
                        <div class="media">
                            <i class="fa fa-envelope-o" aria-hidden="true"></i>
                            <div class="media-body">
                                <p>moshiur.sumon.neil@gmail.com</p>
                            </div>
                        </div>
                        <div class="media">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                            <div class="media-body">
                                <p class="f_rubik">01311xxxxxx</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4 social-link">
                  <h5>Social Media Link</h5>
                    <div class="footer-content">
                      <ul class="list-inline">
                        <li class="list-inline-item"><a href="#"><i class="fa fa-facebook"
                                        aria-hidden="true"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-twitter"
                                        aria-hidden="true"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-instagram"
                                        aria-hidden="true"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-youtube-play"
                                        aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer> 
</body>
</html>
