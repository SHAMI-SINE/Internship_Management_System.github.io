<?php
    
     include ("database/database-connection.php");

     if(isset($_SESSION['username4'], $_SESSION['role4'])){
           header("location:admin-dashboard.php");  
     }  
      
      
     $msg = "";

     if(isset($_POST['submit'])){
           $username = $_POST['username'];
           $password = $_POST['password'];
           $userType = $_POST['userType'];

           $sql = "SELECT * FROM admin WHERE username=? AND password=? AND user_type=? ";

           $stmt = $conn->prepare($sql);
           $stmt->bind_param("sss", $username,$password, $userType);
           $stmt->execute();
           $result = $stmt->get_result();
           $row = $result->fetch_assoc();

           if($result->num_rows == 1 ){

             session_regenerate_id();
             $_SESSION['username4'] = $row['username'];
             $_SESSION['role4'] = $row['user_type'];
             session_write_close();

             if($_SESSION['role4'] == 'admin'){
                header("location:admin-dashboard.php");   
             }       
           }  
           else
           {
              $msg ="*Please enter valid information";
           }
     }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>NSU Internship Management System</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@500;600;700&amp;display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Rubik&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <header id="header">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <img src="images/logo/Logo.png" class="w-100 main-logo" alt="Logo" title="Logo" />
                </a>

                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="categories.php">Categories</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about-us.php">About Us</a>
                        </li>
                        <li class="nav-item drop-down">
                            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">Pages</a>
                            <div class="mega-menu fadeIn dropdown-menu">
                                <div class="row">
                                    <div class="col-sm-3 border-right">
                                        <ul class="list-unstyled">
                                            <li><a class="dropdown-item" href="company-register.html">Company Register</a></li>
                                            <li><a class="dropdown-item" href="company-login.html">Company Login</a></li>
                                            <li><a class="dropdown-item" href="company-list.html">Company List</a></li>
                                        </ul>
                                    </div>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact-us.php">Contact</a>
                        </li>
                    </ul>

                    <ul class="navbar-nav navbar-right">
                        <li>
                            <div class="btn-group">
                               <button type="button" class="btn btn-danger">Login</button>
                               <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                               <span class="sr-only">Toggle Dropdown</span></button>

                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="student-login.php">Student Login</a>
                                <a class="dropdown-item" href="company-login.php">Company Login</a>
                                <a class="dropdown-item" href="faculty-login.php">Faculty Login</a>
                                <a class="dropdown-item" href="admin-login.php">Admin Login</a>
                            </div>
                        </div>
                        </li>

                         <li>
                            <div class="btn-group">
                               <button type="button" class="btn btn-danger">Registration</button>
                               <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                               <span class="sr-only">Toggle Dropdown</span></button>

                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="student-registration.php">Student Registration</a>
                                <a class="dropdown-item" href="company-registration.php">Company Registration</a>
                                <a class="dropdown-item" href="faculty-registration.php">Faculty Registration</a>
                            </div>
                        </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

        <section class="loginForm">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 mx-auto">
                      <div class="card m-4">
                          <div class="card-body bg-light text-center">
                               <form method="post">
                            <h3 class="text-center">Admin Login</h3>
                            <img src="images/logo/admin-login.jpg" alt="user" height="100" width="100" class="rounded-circle mx-auto d-block">
                            <div class="latestForm">
                    
                                <div class="form-group"> 
                                    <input type="text" name="username" id="userName" class="form-control" value="" required> 
                                    <label class="form-control-placeholder" for="userName">Username</label>
                                    <i class="fa fa-user-o iconSet" aria-hidden="true"></i>
                                </div>
                        
                                <div class="form-group"> 
                                    <input type="password" name="password" id="password" class="form-control" value="" required> 
                                    <label class="form-control-placeholder" for="password">Password</label> 
                                    <i class="fa fa-lock iconSet" aria-hidden="true"></i>
                                </div> 
                            </div> 
                    
                            <div class="row my-4">
                                <div class="col d-flex justify-content-left">
                                
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" name="savepassword" class="custom-control-input" id="savePwd" checked required>
                                        <label class="custom-control-label" for="savePwd">Save Password</label>
                                    </div>
                                </div>
        
                                <div class="col text-right">
                                  <a class="forgotPwd" href="forgot-password.html">Forgot password?</a>
                                </div>
                            </div>
                            <input type="hidden" id="userType" name="userType" value="admin">
                            <input type="submit" name="submit" class="btn btn-danger btn-block" id="login">
                            <p><?php echo $msg; ?></p>
                               </form>
                          </div>    
                       </div>       
                    </div>
                </div>
            </div>
        </section>
        
        <footer id="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-4 about-nsu-intern">
                        <div class="col-sm-6">
                            <a class="logo-two" href="index.html">
                                <img src="images/logo/Logo.png" class="w-100 main-logo" alt="Logo" title="Logo" />
                            </a>
                        </div>
                        <div class="col-sm-6">
                            <div class="footer-content">
                                <p></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 contact-us-info">
                        <h5>Contact Us</h5>
                        <div class="footer-content">
                            <div class="media">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                                <div class="media-body">
                                    <p>Block- A, Level-1, Bashundhara RA, Dhaka</p>
                                </div>
                            </div>
    
                            <div class="media">
                                <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                <div class="media-body">
                                    <p>moshiur.sumon.neil@gmail.com</p>
                                </div>
                            </div>
    
                            <div class="media">
                                <i class="fa fa-phone" aria-hidden="true"></i>
                                <div class="media-body">
                                    <p class="f_rubik">01311xxxxxx</p>
                                </div>
                            </div>
    
                        </div>
                    </div>
                    <div class="col-sm-4 social-link">
                        <h5>Social Media Link</h5>
                        <div class="footer-content">
                            <ul class="list-inline">
                                <li class="list-inline-item"><a href="#"><i class="fa fa-facebook"
                                            aria-hidden="true"></i></a></li>
                                <li class="list-inline-item"><a href="#"><i class="fa fa-twitter"
                                            aria-hidden="true"></i></a></li>
                                <li class="list-inline-item"><a href="#"><i class="fa fa-instagram"
                                            aria-hidden="true"></i></a></li>
                                <li class="list-inline-item"><a href="#"><i class="fa fa-youtube-play"
                                            aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
</body>
</html>