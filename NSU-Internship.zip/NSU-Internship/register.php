<!DOCTYPE html>
<html lang="en">
<head>
    <title>NSU Internship Management System</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@500;600;700&amp;display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Rubik&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
        <header id="header">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="index.html">
                    <img src="images/logo/Logo.png" class="w-100 main-logo" alt="Logo" title="Logo" />
                </a>

                <button class="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav navbar-center ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="categories.php">Categories</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about-us.php">About Us</a>
                        </li>
                        <li class="nav-item drop-down">
                            <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">Pages</a>
                            <div class="mega-menu fadeIn  dropdown-menu">
                                <ul class="list-unstyled">
                                    <li><a class="dropdown-item" href="company-register.html">Company Register</a></li>
                                    <li><a class="dropdown-item" href="company-login.html">Company Login</a></li>
                                    <li><a class="dropdown-item" href="company-list.html">Company List</a></li>
                                    <li><a class="dropdown-item" href="internship-list.html">Internship List</a></li>
                                </ul>
                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="contact-us.php">Contact</a>
                        </li>
                    </ul>

                    <ul class="navbar-nav navbar-right">
                            <a class="btn btn1  my-2 my-sm-0" href="login.php">Login</a>
                            <a class="btn btn2 my-2 my-sm-0" href="register.php">Sign Up</a>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>
        </header>

        <section class="loginForm">
	    <div class="container">
		  <div class="row">
			 <div class="col-sm-6 mx-auto">	
				<form method="post">
					<h3 class="text-center">REGISTRATION - AS A ADMIN</h3>
					
					<div class="latestForm">
			
						<div class="form-group"> 
							<input type="text" name="firstname" id="firstName" class="form-control" value="" required> 
							<label class="form-control-placeholder" for="firstName">First Name</label>
							<i class="fa fa-user-o iconSet" aria-hidden="true"></i>
						</div>
					
						<div class="form-group"> 
							<input type="text" name="lastname" id="lastName" class="form-control" value="" required> 
							<label class="form-control-placeholder" for="lastName">Last Name</label>
							<i class="fa fa-user-o iconSet" aria-hidden="true"></i>
						</div>
					
						<div class="form-group"> 
							<input type="email" name="email" id="email" class="form-control" value="" required> 
							<label class="form-control-placeholder" for="email">E-mail Address</label>
							<i class="fa fa-envelope-o iconSet" aria-hidden="true"></i>
						</div>
				
						<div class="form-group"> 
							<input type="text" name="username" id="userName" class="form-control" value="" required> 
							<label class="form-control-placeholder" for="userName">Username</label>
							<i class="fa fa-user-o iconSet" aria-hidden="true"></i>
						</div>
					
						<div class="form-group"> 
							<input type="password" name="password" id="password" class="form-control" value="" required> 
							<label class="form-control-placeholder" for="password">Password</label> 
							<i class="fa fa-lock iconSet" aria-hidden="true"></i>
						</div> 
			
						<div class="form-group"> 
							<input type="password" name="conpassword" id="conpwd" class="form-control" value="" required> 
							<label class="form-control-placeholder" for="conpwd">Confirm Password</label> 
							<i class="fa fa-lock iconSet" aria-hidden="true"></i>
						</div> 
					</div> 
					<input type="submit" name="submit" class="btn btn-danger btn-block mb-4" id="register" value="Register Now">

				</form>			
			</div>
		</div>
	</div>
        </section>

        <footer id="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-4 about-nsu-intern">
                        <div class="col-sm-6">
                            <a class="logo-two" href="index.html">
                                <img src="images/logo/Logo.png" class="w-100 main-logo" alt="Logo" title="Logo" />
                            </a>
                        </div>
                        <div class="col-sm-6">
                            <div class="footer-content">
                                <p></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 contact-us-info">
                        <h5>Contact Us</h5>
                        <div class="footer-content">
                            <div class="media">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                                <div class="media-body">
                                    <p>Block- A, Level-1, Bashundhara RA, Dhaka</p>
                                </div>
                            </div>
    
                            <div class="media">
                                <i class="fa fa-envelope-o" aria-hidden="true"></i>
                                <div class="media-body">
                                    <p>moshiur.sumon.neil@gmail.com</p>
                                </div>
                            </div>
    
                            <div class="media">
                                <i class="fa fa-phone" aria-hidden="true"></i>
                                <div class="media-body">
                                    <p class="f_rubik">01311xxxxxx</p>
                                </div>
                            </div>
    
                        </div>
                    </div>
                    <div class="col-sm-4 social-link">
                        <h5>Social Media Link</h5>
                        <div class="footer-content">
                            <ul class="list-inline">
                                <li class="list-inline-item"><a href="#"><i class="fa fa-facebook"
                                            aria-hidden="true"></i></a></li>
                                <li class="list-inline-item"><a href="#"><i class="fa fa-twitter"
                                            aria-hidden="true"></i></a></li>
                                <li class="list-inline-item"><a href="#"><i class="fa fa-instagram"
                                            aria-hidden="true"></i></a></li>
                                <li class="list-inline-item"><a href="#"><i class="fa fa-youtube-play"
                                            aria-hidden="true"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>

		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/popper.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>
